package parkingTicketSimulator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class SimulatorDriver
{

	public static void main(String[] args)
	{
		ArrayList<ParkingSpace> parkingSpaceList = new ArrayList<ParkingSpace>();
		PoliceOfficer cop = new PoliceOfficer("Bob Duncan", 23455664);
		
		try
		{
			System.out.println("Parking Ticket");
			System.out.println("---------------------------------");
			Scanner inFile = new Scanner(new File("cars.txt"));
			while(inFile.hasNextLine())
			{
				if(("ParkingSpace:").contentEquals(inFile.nextLine()))
				{
					inFile.nextLine();
					int meterTime = inFile.nextInt();
					ParkingMeter meter = new ParkingMeter(meterTime);
					inFile.nextLine();
					inFile.nextLine();
					String driverName = inFile.nextLine().strip();
					int driverID = inFile.nextInt();
					inFile.nextLine();
					LicensedDriver driver = new LicensedDriver(driverName,driverID);
					String make = inFile.nextLine().strip();
					String model = inFile.nextLine().strip();
					String color = inFile.nextLine().strip();
					String plate = inFile.nextLine().strip();
					int timeParked = inFile.nextInt();
					
					// create new space for each car for driver
					ParkedCar parkedCar = new ParkedCar(make,model,color,plate,timeParked);
					ParkingSpace carParkingSpace = new ParkingSpace(parkedCar, meter);
					parkingSpaceList.add(carParkingSpace);

				}
			}
		} catch(FileNotFoundException ex)
		{
			System.out.println("Please input correct file");
		}
		ParkingTicket ticket;
		
		ticket = (cop).issueTicket(parkingSpaceList.get(1).getCar(), parkingSpaceList.get(2).getMeter());
		System.out.println(ticket);
	}

}


